let button;

function setup() {
  createCanvas(600, 600);
  button = createButton('Smash for Subliminal Message');
  button.position(110, 400);
  button.mousePressed(Smiley);
}
let value = 'Red';
let Screenvalue = 'Black';
let Button2Effect = 'Yellow'


function draw() {

  background(220);
  fill(255);
  square(100, 35, 400, 20)
  //round backing
  //---------------------
  fill(Button2Effect);
  circle(300, 220, 180);
  fill('Black');
  circle(330, 200, 40);
  circle(270, 200, 40);
  line(270, 250, 330, 260, );
  //---------------------
  fill(Screenvalue);
  square(135, 65, 330);
  //inner screen
  //---------------------------------------------------------
  ellipseMode(RADIUS); // Set to RADIUS
  fill(255); // Set fill to white
  ellipse(300, 600, 180, 165);
  //Make Mac like Stand
  ellipseMode(CENTER); // Set to CENTER
  fill(100); // Set fill to gray
  ellipse(300, 600, 180, 165); // mac stand fill elipse 
  //---------------------------------------------------------
  //---------------------------------------------------------
  if (keyIsPressed === true) {
    fill('Green');
  } else {
    fill('Red');
  }
  ellipse(360, 415, 30, 30);
  //---------------------------------------------------------
  fill(value);
  rect(440, 400, 45, 25, 20);
}

function Smiley() {
  fill(Button2Effect);
  circle(300, 220, 180);
  fill('Black');
  circle(330, 200, 40);
  circle(270, 200, 40);
  line(270, 250, 330, 260, );
  //Make Meh Face appear
}

function mouseClicked() {
  if (value === 'Green') {
    value = 'Red';
    Screenvalue = 'Black';
  } else {
    value = 'Green';
    Screenvalue = 'Blue';
    //Turn screen from black to Blue
  };
}
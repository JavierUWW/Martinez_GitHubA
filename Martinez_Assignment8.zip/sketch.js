var img0;
var img1;
var gif;
var png;
var text0 = "We're soarin', flyin...";

function preload() {
	img0 = loadImage("Birb.jpg");
    img1 = loadImage("Birb2.jpg");
    gif = loadImage("Clouds.gif");
   // png = loadImage("CapRun.png");
}

function setup() {
  createCanvas(400, 400);
  textFont("Comic Neue");
  fill(0);
  stroke(255);
}

function draw() {
  background('Blue');

    image(gif, 0, 0);
    image(gif, mouseX * .5, mouseY * .5)

    text(text0, 150, 200, 200, 200);
    
    image(img0, 0, 0, 100,100);

    image(img1, 350, 350,50,50);
    image(img1, mouseX * 1, mouseY * 1, 50, 50)
  
	
}
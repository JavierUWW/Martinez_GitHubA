
var x = []; // Declare the array

function setup() {

	createCanvas(400, 400);

	noStroke();

	fill(255, 200);

	for (var i = 0; i < 3000; i++) {

		//assign values to array based on for loop
		x[i] = random(-500, 200); 
      print('The length of this array is '+ x.length );
	}

}

function draw() {

	background('Purple');

	for (var i = 0; i < x.length; i++) {

		x[i] +=0.5;

		// use the i variable to determine y variable, sets position on y-axis
		var y = i * 0.4;

		// use the modified array value and the y value in this loop to draw an arc shape
		//arc(x[i], y, 12, 12, 0.52, 5.76);
      fill('Black');
      rect(x[i] - 1, y, 2, -12)
      fill('Orange'); // Pumpkins
      ellipse(x[i], y, 7, 12);
      ellipse(x[i] + 3, y, 7, 12);
      ellipse(x[i] - 3, y, 6, 12);
    }

}